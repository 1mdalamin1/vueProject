<template>
  <div>
    <h2>Dashboard Page componant</h2>
  </div>
</template>
<script>
export default {};
</script>
<style></style>
